/*
   �������Ļ�������
*/
#include "malloc.h"
#include "stdio.h"

#define MAXSIZE 100

/*���������Ĵ洢�ṹ*/
typedef char DataType;
typedef struct Node
{
	DataType data;
	struct Node *left;
	struct Node *right;
}BTNode,*PBTNode,*BiTreeLink;

/*�㷨6-1����������*/
BiTreeLink CreateBiTree(char *nodes,int pos,int num)
{
	PBTNode p;
	if(nodes[pos]==' ' || pos>num)
		return NULL;
	p=(PBTNode)malloc(sizeof(BTNode));
	if(!p)
	{
		printf("��ʼ����������\n");
		return 0;
	}
	p->data=nodes[pos];
	p->left=CreateBiTree(nodes,2*pos,num);
	p->right=CreateBiTree(nodes,2*pos+1,num);
	return p;
}


/*�㷨6-2��ʾ������*/
void DispBiTree(BiTreeLink root)
{
	int front,rear;
	PBTNode queue[MAXSIZE];
	PBTNode p;
	if(root==NULL)
		return;
	queue[0]=root;
	front=0;
	rear=1;
	while(front<rear)
	{
		p=queue[front];
		front=(front+1)%MAXSIZE;
		if(p==NULL)
			printf("( )");
		else
		{
			printf("(%c)",p->data);		
			queue[rear]=p->left;
			rear=(rear+1)%MAXSIZE;
			queue[rear]=p->right;
			rear=(rear+1)%MAXSIZE;
		}		
	}
}


/*�㷨6-3�����Һ���*/
PBTNode InsertRight(PBTNode r,DataType x)
{
	PBTNode p;
	if(!r) return NULL;
	p=(PBTNode)malloc(sizeof(BTNode));
	p->data=x;
	p->left=NULL;
	p->right=r->right;
	r->right=p;
	return p;
}


/*�㷨6-5��������*/
void ReleaseTree(PBTNode *r)
{
	if(*r)
	{
		ReleaseTree(&(*r)->left);	
		ReleaseTree(&(*r)->right);
		free(*r);
	}
}


/*�㷨6-4ɾ��������*/
void DeleteRight(PBTNode r)
{
	if(!r) return;
	ReleaseTree(&r->right);
	r->right=NULL;	
}



/*�㷨6-6ǰ�����*/
void PreOrder(BiTreeLink r)
{
	if(r!=NULL)
	{
		printf("%c",r->data);
		PreOrder(r->left);
		PreOrder(r->right);
	}
}


/*�㷨6-7ǰ������ǵݹ��㷨*/
void NonPreOrder(BiTreeLink r)
{
	PBTNode stack[MAXSIZE],p;
	int top=-1;
	p=r;
	while(p || top>-1)
	{
		if(p)
		{
			printf("%c",p->data);
			stack[++top]=p;
			p=p->left;
			
		}
		else
		{
			p=stack[top--];			
			p=p->right;			
		}
	}
}


/*�㷨6-8�������*/
void InOrder(BiTreeLink r)
{
	if(r!=NULL)
	{
		InOrder(r->left);
		printf("%c",r->data);
		InOrder(r->right);
	}
}

/*�㷨6-9��������ǵݹ��㷨*/
void NonInOrder(BiTreeLink r)
{
	PBTNode stack[MAXSIZE],p;
	int top=-1;
	p=r;
	while(p || top>-1)
	{
		if(!p)
		{
			p=stack[top--];
			printf("%c",p->data);
			p=p->right;
		}
		else
		{
			stack[++top]=p;
			p=p->left;
		}
	}
}


/*�㷨6-10�������*/
void PostOrder(BiTreeLink r)
{
	if(r!=NULL)
	{
		PostOrder(r->left);		
		PostOrder(r->right);
		printf("%c",r->data);
	}
}


/*�㷨6-11��������ǵݹ��㷨*/
void NonPostOrder(BiTreeLink r)
{   
	PBTNode stack[MAXSIZE],p;
	int flags[MAXSIZE];
	int top=-1;
	int flag;
	p=r;
    do
    { 
		if(p)
		{  
			flag=0;			
			stack[++top]=p;	
			flags[top]=flag;
			p=p->left;
		}
		else
		{  
			flag=flags[top];
			p=stack[top--];
			if(flag==0)
			{  
				flag=1;	
				stack[++top]=p;
				flags[top]=flag;
				p=p->right;
			}
			else
			{  
				printf("%c",p->data);
				p=NULL;
			}
		}
    }while(p||top>-1);
} 


/*�㷨6-12ͳ�ƶ������н�����*/
int BiTreeCount(BiTreeLink r)
{
	if(r==NULL) return 0;
	else
		return BiTreeCount(r->left)+BiTreeCount(r->right)+1;
}


/*�㷨6-13������������*/
int BiTreeDepth(BiTreeLink r)
{
	int ld,rd;
	if(r==NULL)
		return 0;
	else
	{
		ld=BiTreeDepth(r->left);
		rd=BiTreeDepth(r->right);
		return ld>rd ? ld+1 : rd+1;
	}
}


/*�㷨6-14���Ҷ�������ֵΪx�Ľ��*/
PBTNode FindNode(BiTreeLink r,DataType x)
{
	PBTNode p;
	if(r==NULL)
		return NULL;
	if(r->data==x)
		return r;
	p=FindNode(r->left,x);
	if(p)  return p;
	else
		return FindNode(r->right,x);
}
